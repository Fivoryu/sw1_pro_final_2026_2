from __future__ import annotations

import uuid
from collections.abc import Generator
from datetime import datetime, timedelta, timezone
from typing import Any, cast

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response, status
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy import select, update
from sqlalchemy.engine import CursorResult
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.security import (
    create_access_token,
    decrypt_totp_secret,
    encrypt_totp_secret,
    hash_password,
    hash_secret,
    make_totp_uri,
    new_recovery_codes,
    new_totp_secret,
    random_token,
    verify_password,
    verify_totp,
)
from app.modules.identity.bootstrap import normalize_email
from app.modules.identity.models import (
    EnrollmentChallenge,
    LoginChallenge,
    RecoveryCode,
    StaffAccount,
    StaffInvitation,
    StaffSession,
)

router = APIRouter(prefix="/api/v1/auth", tags=["staff-auth"])
REFRESH_COOKIE = "roomforge_refresh"
CSRF_HEADER = "X-CSRF-Token"


class StrictRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")


class InvitationAcceptance(StrictRequest):
    token: str = Field(min_length=20, max_length=256)
    password: str = Field(min_length=8, max_length=256)
    password_confirmation: str = Field(min_length=8, max_length=256)


class TOTPEnrollmentVerification(StrictRequest):
    enrollment_token: str = Field(min_length=20, max_length=256)
    code: str = Field(min_length=6, max_length=6)


class LoginRequest(StrictRequest):
    email: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=8, max_length=256)


class LoginTOTPRequest(StrictRequest):
    challenge_token: str = Field(min_length=20, max_length=256)
    code: str | None = Field(default=None, min_length=6, max_length=6)
    recovery_code: str | None = Field(default=None, min_length=8, max_length=64)

    @model_validator(mode="after")
    def exactly_one_code(self) -> LoginTOTPRequest:
        if (self.code is None) == (self.recovery_code is None):
            raise ValueError("Provide exactly one authentication code")
        return self


def _utc(value: datetime) -> datetime:
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def _clock(request: Request) -> datetime:
    value = request.app.state.clock()
    return _utc(value)


def _settings(request: Request) -> Settings:
    return request.app.state.settings


def _db(request: Request) -> Generator[Session, None, None]:
    session = request.app.state.session_factory()
    try:
        yield session
    finally:
        session.close()


def _unauthorized() -> HTTPException:
    return HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication failed")


def _origin_is_valid(origin: str | None, settings: Settings) -> bool:
    return origin is not None and origin.rstrip("/") == settings.web_origin.rstrip("/")


def _require_origin(origin: str | None, settings: Settings) -> None:
    if not _origin_is_valid(origin, settings):
        raise HTTPException(status_code=403, detail="Request origin is not allowed")


def _set_auth_cookies(
    response: Response,
    *,
    refresh_token: str,
    csrf_token: str,
    settings: Settings,
    max_age: int,
) -> None:
    response.set_cookie(
        REFRESH_COOKIE,
        refresh_token,
        max_age=max_age,
        httponly=True,
        secure=settings.secure_cookies,
        samesite="strict",
        path="/api/v1/auth",
    )
    response.set_cookie(
        "roomforge_csrf",
        csrf_token,
        max_age=max_age,
        httponly=False,
        secure=settings.secure_cookies,
        samesite="strict",
        path="/api/v1/auth",
    )


def _clear_auth_cookies(response: Response, settings: Settings) -> None:
    response.delete_cookie(REFRESH_COOKIE, path="/api/v1/auth", secure=settings.secure_cookies, httponly=True, samesite="strict")
    response.delete_cookie("roomforge_csrf", path="/api/v1/auth", secure=settings.secure_cookies, samesite="strict")


def _auth_response(
    *,
    session: Session,
    user: StaffAccount,
    settings: Settings,
    now: datetime,
    response: Response,
) -> dict[str, object]:
    refresh_token = random_token()
    csrf_token = random_token()
    auth_session = StaffSession(
        id=str(uuid.uuid4()),
        user_id=user.id,
        refresh_hash=hash_secret(refresh_token),
        csrf_hash=hash_secret(csrf_token),
        created_at=now,
        last_activity_at=now,
        expires_at=now + timedelta(days=settings.refresh_token_days),
    )
    session.add(auth_session)
    session.flush()
    access_token = create_access_token(
        user_id=user.id,
        session_id=auth_session.id,
        signing_key=settings.jwt_secret,
        now=now,
        lifetime_minutes=settings.access_token_minutes,
    )
    session.commit()
    _set_auth_cookies(
        response,
        refresh_token=refresh_token,
        csrf_token=csrf_token,
        settings=settings,
        max_age=settings.refresh_token_days * 24 * 60 * 60,
    )
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "csrf_token": csrf_token,
        "user": _user_projection(user),
    }


def _user_projection(user: StaffAccount) -> dict[str, str | None]:
    return {"id": user.id, "email": user.email, "role": user.role, "tenant_id": user.tenant_id}


def _consume_recovery_code(session: Session, user_id: str, raw_code: str, now: datetime) -> bool:
    result = cast(
        CursorResult[Any],
        session.execute(
            update(RecoveryCode)
            .where(
                RecoveryCode.user_id == user_id,
                RecoveryCode.code_hash == hash_secret(raw_code),
                RecoveryCode.used_at.is_(None),
            )
            .values(used_at=now)
        ),
    )
    return result.rowcount == 1


def _check_csrf(session: Session, auth_session: StaffSession, supplied: str | None) -> None:
    if not supplied or not secrets_compare(hash_secret(supplied), auth_session.csrf_hash):
        raise HTTPException(status_code=403, detail="Request verification failed")


def secrets_compare(left: str, right: str) -> bool:
    import hmac

    return hmac.compare_digest(left, right)


def _session_is_expired(auth_session: StaffSession, user: StaffAccount, now: datetime, settings: Settings) -> bool:
    if auth_session.revoked_at is not None or _utc(auth_session.expires_at) <= now:
        return True
    if user.role in {"platform_admin", "agency_admin"}:
        return _utc(auth_session.last_activity_at) + timedelta(minutes=settings.admin_idle_minutes) <= now
    return False


@router.post("/invitations/accept")
def accept_invitation(
    payload: InvitationAcceptance,
    request: Request,
    session: Session = Depends(_db),
) -> dict[str, str]:
    if payload.password != payload.password_confirmation:
        raise HTTPException(status_code=422, detail="Invitation details are invalid")
    now = _clock(request)
    invitation = session.scalar(
        select(StaffInvitation).where(StaffInvitation.token_hash == hash_secret(payload.token))
    )
    if invitation is None or invitation.status != "pending" or _utc(invitation.expires_at) <= now:
        raise _unauthorized()
    enrollment = session.scalar(
        select(EnrollmentChallenge).where(EnrollmentChallenge.invitation_id == invitation.id)
    )
    if enrollment is not None and (
        enrollment.consumed_at is not None or _utc(enrollment.expires_at) > now
    ):
        raise _unauthorized()
    settings = _settings(request)
    enrollment_token = random_token()
    totp_secret = new_totp_secret()
    if enrollment is None:
        enrollment = EnrollmentChallenge(
            invitation_id=invitation.id,
            token_hash=hash_secret(enrollment_token),
            password_hash=hash_password(payload.password),
            totp_secret_encrypted=encrypt_totp_secret(totp_secret, settings.totp_encryption_key),
            created_at=now,
            expires_at=now + timedelta(minutes=settings.enrollment_ttl_minutes),
            attempts=0,
        )
        session.add(enrollment)
    else:
        enrollment.token_hash = hash_secret(enrollment_token)
        enrollment.password_hash = hash_password(payload.password)
        enrollment.totp_secret_encrypted = encrypt_totp_secret(totp_secret, settings.totp_encryption_key)
        enrollment.created_at = now
        enrollment.expires_at = now + timedelta(minutes=settings.enrollment_ttl_minutes)
        enrollment.attempts = 0
        enrollment.consumed_at = None
    session.commit()
    return {
        "enrollment_token": enrollment_token,
        "totp_secret": totp_secret,
        "otpauth_uri": make_totp_uri(totp_secret, invitation.email),
    }


@router.post("/totp/enroll/verify")
def verify_totp_enrollment(
    payload: TOTPEnrollmentVerification,
    request: Request,
    session: Session = Depends(_db),
) -> dict[str, list[str]]:
    now = _clock(request)
    challenge = session.scalar(
        select(EnrollmentChallenge).where(EnrollmentChallenge.token_hash == hash_secret(payload.enrollment_token))
    )
    if (
        challenge is None
        or challenge.consumed_at is not None
        or _utc(challenge.expires_at) <= now
        or challenge.attempts >= 5
    ):
        raise _unauthorized()
    challenge.attempts += 1
    settings = _settings(request)
    invitation = session.get(StaffInvitation, challenge.invitation_id)
    if invitation is None or invitation.status != "pending" or _utc(invitation.expires_at) <= now:
        session.commit()
        raise _unauthorized()
    totp_secret = decrypt_totp_secret(challenge.totp_secret_encrypted, settings.totp_encryption_key)
    if not verify_totp(totp_secret, payload.code, now):
        if challenge.attempts >= 5:
            challenge.consumed_at = now
        session.commit()
        raise _unauthorized()

    user = StaffAccount(
        email=invitation.email,
        password_hash=challenge.password_hash,
        role=invitation.role,
        tenant_id=invitation.tenant_id,
        active=True,
        totp_secret_encrypted=challenge.totp_secret_encrypted,
        totp_enabled=True,
        created_at=now,
    )
    session.add(user)
    invitation.status = "accepted"
    invitation.accepted_at = now
    challenge.consumed_at = now
    recovery_codes = new_recovery_codes(settings.recovery_code_count)
    session.flush()
    for code in recovery_codes:
        session.add(
            RecoveryCode(
                user_id=user.id,
                code_hash=hash_secret(code),
                created_at=now,
                used_at=None,
            )
        )
    session.commit()
    return {"recovery_codes": recovery_codes}


@router.post("/login")
def login(
    payload: LoginRequest,
    request: Request,
    response: Response,
    session: Session = Depends(_db),
    origin: str | None = Header(default=None),
) -> dict[str, object]:
    now = _clock(request)
    try:
        email = normalize_email(payload.email)
    except ValueError:
        email = "invalid@example.test"
    user = session.scalar(select(StaffAccount).where(StaffAccount.email == email))
    password_ok = user is not None and verify_password(user.password_hash, payload.password)
    if not password_ok or user is None or not user.active:
        raise _unauthorized()
    if user.role in {"platform_admin", "agency_admin"}:
        if not user.totp_enabled or not user.totp_secret_encrypted:
            raise _unauthorized()
        challenge_token = random_token()
        session.add(
            LoginChallenge(
                user_id=user.id,
                token_hash=hash_secret(challenge_token),
                created_at=now,
                expires_at=now + timedelta(minutes=_settings(request).login_challenge_minutes),
                attempts=0,
            )
        )
        session.commit()
        return {"mfa_required": True, "challenge_token": challenge_token}

    settings = _settings(request)
    _require_origin(origin, settings)
    return _auth_response(session=session, user=user, settings=settings, now=now, response=response)


@router.post("/login/totp")
def complete_login_challenge(
    payload: LoginTOTPRequest,
    request: Request,
    response: Response,
    session: Session = Depends(_db),
    origin: str | None = Header(default=None),
) -> dict[str, object]:
    now = _clock(request)
    challenge = session.scalar(
        select(LoginChallenge).where(LoginChallenge.token_hash == hash_secret(payload.challenge_token))
    )
    if (
        challenge is None
        or challenge.consumed_at is not None
        or _utc(challenge.expires_at) <= now
        or challenge.attempts >= 5
    ):
        raise _unauthorized()
    user = session.get(StaffAccount, challenge.user_id)
    if user is None or not user.active or not user.totp_enabled or not user.totp_secret_encrypted:
        raise _unauthorized()
    accepted = False
    if payload.code is not None:
        settings = _settings(request)
        secret = decrypt_totp_secret(user.totp_secret_encrypted, settings.totp_encryption_key)
        accepted = verify_totp(secret, payload.code, now)
    elif payload.recovery_code is not None:
        accepted = _consume_recovery_code(session, user.id, payload.recovery_code, now)
    if not accepted:
        challenge.attempts += 1
        challenge.consumed_at = now
        session.commit()
        raise _unauthorized()

    settings = _settings(request)
    _require_origin(origin, settings)
    challenge.consumed_at = now
    result = _auth_response(session=session, user=user, settings=settings, now=now, response=response)
    return result


@router.post("/refresh")
def refresh_session(
    request: Request,
    response: Response,
    session: Session = Depends(_db),
    origin: str | None = Header(default=None),
    csrf_token: str | None = Header(default=None, alias=CSRF_HEADER),
) -> dict[str, object]:
    settings = _settings(request)
    _require_origin(origin, settings)
    raw_refresh = request.cookies.get(REFRESH_COOKIE)
    if not raw_refresh:
        raise _unauthorized()
    auth_session = session.scalar(
        select(StaffSession).where(StaffSession.refresh_hash == hash_secret(raw_refresh))
    )
    if auth_session is None:
        raise _unauthorized()
    _check_csrf(session, auth_session, csrf_token)
    now = _clock(request)
    user = session.get(StaffAccount, auth_session.user_id)
    if user is None or not user.active or _session_is_expired(auth_session, user, now, settings):
        auth_session.revoked_at = now
        session.commit()
        raise _unauthorized()
    new_refresh = random_token()
    new_csrf = random_token()
    auth_session.refresh_hash = hash_secret(new_refresh)
    auth_session.csrf_hash = hash_secret(new_csrf)
    auth_session.last_activity_at = now
    access_token = create_access_token(
        user_id=user.id,
        session_id=auth_session.id,
        signing_key=settings.jwt_secret,
        now=now,
        lifetime_minutes=settings.access_token_minutes,
    )
    session.commit()
    _set_auth_cookies(
        response,
        refresh_token=new_refresh,
        csrf_token=new_csrf,
        settings=settings,
        max_age=settings.refresh_token_days * 24 * 60 * 60,
    )
    return {"access_token": access_token, "token_type": "bearer", "csrf_token": new_csrf}


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    request: Request,
    response: Response,
    session: Session = Depends(_db),
    origin: str | None = Header(default=None),
    csrf_token: str | None = Header(default=None, alias=CSRF_HEADER),
) -> Response:
    settings = _settings(request)
    _require_origin(origin, settings)
    raw_refresh = request.cookies.get(REFRESH_COOKIE)
    if raw_refresh:
        auth_session = session.scalar(
            select(StaffSession).where(StaffSession.refresh_hash == hash_secret(raw_refresh))
        )
        if auth_session is not None:
            _check_csrf(session, auth_session, csrf_token)
            auth_session.revoked_at = _clock(request)
            session.commit()
    _clear_auth_cookies(response, settings)
    response.status_code = status.HTTP_204_NO_CONTENT
    return response


def current_user(
    request: Request,
    authorization: str | None = Header(default=None),
    session: Session = Depends(_db),
) -> StaffAccount:
    if authorization is None or not authorization.startswith("Bearer "):
        raise _unauthorized()
    settings = _settings(request)
    try:
        from app.core.security import decode_access_token

        claims = decode_access_token(authorization[7:], settings.jwt_secret)
    except Exception:
        raise _unauthorized() from None
    user_id = claims.get("sub")
    session_id = claims.get("sid")
    if not isinstance(user_id, str) or not isinstance(session_id, str):
        raise _unauthorized()
    auth_session = session.get(StaffSession, session_id)
    user = session.get(StaffAccount, user_id)
    now = _clock(request)
    if (
        auth_session is None
        or user is None
        or auth_session.user_id != user.id
        or not user.active
        or _session_is_expired(auth_session, user, now, settings)
    ):
        if auth_session is not None and auth_session.revoked_at is None:
            auth_session.revoked_at = now
            session.commit()
        raise _unauthorized()
    auth_session.last_activity_at = now
    session.commit()
    return user


@router.get("/me")
def me(user: StaffAccount = Depends(current_user)) -> dict[str, str | None]:
    return _user_projection(user)
