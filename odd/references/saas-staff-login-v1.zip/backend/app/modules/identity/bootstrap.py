from __future__ import annotations

import argparse
import re
import sys
from datetime import datetime, timedelta, timezone
from typing import Callable

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import Settings
from app.core.security import hash_secret, random_token
from app.db.session import create_session_factory
from app.modules.identity.models import StaffAccount, StaffInvitation
from app.modules.identity.notifier import (
    EmailDeliveryUnavailable,
    EmailSender,
    configured_email_sender,
)


def normalize_email(email: str) -> str:
    normalized = email.strip().lower()
    if len(normalized) > 320 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", normalized):
        raise ValueError("A valid email address is required")
    return normalized


def _utc(value: datetime) -> datetime:
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def issue_platform_admin_invitation(
    *,
    session_factory: sessionmaker[Session],
    email_sender: EmailSender,
    email: str,
    settings: Settings,
    clock: Callable[[], datetime],
) -> None:
    normalized_email = normalize_email(email)
    now = _utc(clock())
    raw_token = random_token()
    invitation_id: str
    expires_at = now + timedelta(hours=settings.invitation_ttl_hours)
    with session_factory() as session:
        has_admin = session.scalar(
            select(StaffAccount.id).where(StaffAccount.role == "platform_admin").limit(1)
        )
        pending_invitation = session.scalar(
            select(StaffInvitation).where(
                StaffInvitation.role == "platform_admin",
                StaffInvitation.status == "pending",
            ).limit(1)
        )
        if has_admin or (
            pending_invitation is not None and _utc(pending_invitation.expires_at) > now
        ):
            raise ValueError("The initial platform administrator invitation is unavailable")
        if pending_invitation is not None:
            pending_invitation.status = "expired"
            session.flush()
        invitation = StaffInvitation(
            email=normalized_email,
            role="platform_admin",
            tenant_id=None,
            token_hash=hash_secret(raw_token),
            status="pending",
            issued_at=now,
            expires_at=expires_at,
            delivery_status="pending",
        )
        session.add(invitation)
        try:
            session.commit()
        except IntegrityError as exc:
            session.rollback()
            raise ValueError("The initial platform administrator invitation is unavailable") from exc
        invitation_id = invitation.id

    invite_link = f"{settings.web_origin.rstrip('/')}/accept-invitation/{raw_token}"
    try:
        email_sender.send_invitation(normalized_email, invite_link, expires_at)
    except Exception as exc:
        with session_factory() as session:
            invitation = session.get(StaffInvitation, invitation_id)
            if invitation is not None and invitation.status == "pending":
                invitation.delivery_status = "failed"
                invitation.status = "invalidated"
                session.commit()
        if isinstance(exc, EmailDeliveryUnavailable):
            raise ValueError("Invitation delivery is unavailable; configure an approved transport") from None
        raise ValueError("Invitation delivery failed") from None

    with session_factory() as session:
        invitation = session.get(StaffInvitation, invitation_id)
        if invitation is not None:
            invitation.delivery_status = "delivered"
            session.commit()


def main() -> int:
    parser = argparse.ArgumentParser(description="Issue the one-time initial platform administrator invitation")
    parser.add_argument("--email", required=True, help="Initial platform administrator email")
    args = parser.parse_args()
    engine = None
    try:
        settings = Settings.from_env()
        engine, session_factory = create_session_factory(settings.database_url)
        issue_platform_admin_invitation(
            session_factory=session_factory,
            email_sender=configured_email_sender(),
            email=args.email,
            settings=settings,
            clock=lambda: datetime.now(timezone.utc),
        )
    except (RuntimeError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    finally:
        if engine is not None:
            engine.dispose()
    print("Initial administrator invitation sent")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
